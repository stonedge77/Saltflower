# Conjunction OS — A Foundational Architecture for Cyclic, Distinction-Preserving Computation
## The Unbuilt Gate as Phase Arithmetic

**Authorship Synthesis:** Drawing upon preliminary work outlining foundational gaps in diverse computational substrates (*The Unbuilt Gate*) and synthesizing the unifying mathematical principles across physical systems (*Phase Computation*) into a concrete OS architecture (*Conjunction OS v3*).

---

### Abstract

Conjunction OS is a computational architecture organized around four refusals: it refuses to equate distinct states, it refuses to erase without routing, it refuses to accumulate without closure, and it refuses to treat composition as addition. 

We posit that a fundamental, non-discrete logical primitive — the **Unbuilt Gate** — exists at the nexus of seven disparate fields (Reversible Logic, Biotensegrity, Four-Valued Algebra, Gyroscopic Computation, Subtractive Probability, Flow Automata, Adiabatic Logic). All current literature incorrectly attempts to define this gate using amplitude, voltage, or Boolean state. The necessary primitive is defined by the *negative space* between these fields: **Phase Offset**.

The analysis proves that computation is fundamentally an act of detecting and reading interference patterns in continuous phase space, governed by the symplectic geometry of potentials ($\mathbf{A}$). This unified approach elevates the core finding from mere conceptual gap-filling to a technically defined architecture based on nested oscillators, and then grounds it in checkable software postconditions, typed operators, a four-phase cycle, and an HTTP surface with explicit idempotency and crash-recovery.

**Keywords:** reversible computing, phase logic, Kuramoto, Berry phase, Toffoli, distinction-preserving, event sourcing, non-monotonic learning

---

### 1. Introduction: What an OS Refuses

An operating system is not, first of all, a piece of software. It is a set of commitments about how distinctions are preserved, how information leaves a boundary, and how time is allowed to close.

Modern architectures have made particular choices:
- A Boolean filter returns true/false and discards everything else.
- A gradient-descent loop collapses structural disagreement into a single scalar loss.
- A memory system accumulates state indefinitely and evicts when full.

Each choice lets certain distinctions disappear. The cost surfaces later as unreproducible training dynamics, silent data drift, and unbounded monotonic learning curves.

Conjunction OS asks: **what must an architecture refuse to do if it is to avoid silent collapse?**

### 2. The Cavity: Diagnosis and The Missing Primitive

The original research established that seven non-communicating fields all fail independently to instantiate a single operational primitive. This failure defines the **Cavity**.

Core requirements for $\text{Gate}_{\text{Unbuilt}}$ are eight coexisting constraints:

$\{\alpha \dots \theta\} = \{$
- NAND Foundational (universality),
- Operative Admissibility (avoid false equivalence),
- Four-Phase Clock,
- Phase Encoding,
- Prestress Force-Routing,
- Observer Polarity (signed measurement),
- Bennett Reversibility,
- Continuous "Both" (third value that is not None)
$\}$

Its defining characteristic is its refusals:
1. Refuse to equate distinct states.
2. Refuse to erase without routing.
3. Refuse to accumulate without closure.
4. Refuse composition as addition.

**The central contradiction:** NAND is universal for irreversible logic, but only the Toffoli (and Fredkin) gate is universal for reversible logic. Toffoli acts on three bits: if first two are |1>, it flips the third, otherwise unchanged. It is a universal reversible logic gate. Any Boolean function can be constructed from Toffoli gates, and a NAND is built as `Toffoli(a,b,1) -> (a,b, NAND(a,b))`. The `1` is an ancilla — a prestressed reference. Bennett's discipline requires: compute, copy, uncompute. Any junk produced along the way must be uncomputed to return ancilla qubits to 0.

Therefore, a 2-input NAND that is also reversible is impossible without a history reservoir. The Cavity is real: **amplitude alone is insufficient.**

### 3. The Unifying Principle: Phase Arithmetic as Universal Computation

The gap collapses when the unit of information shifts from amplitude/state to **phase offset ($\phi$)**. Signal is encoded by interference: $\text{Output} \propto |\sum_i A_i e^{i\phi_i}|^2$.

#### 3.1 Historical Precedent: Flow-Routing
From Hero's pneumatics to Al-Jazari's siphon cascades, the variable was continuous pressure/flow — analog state machines where fluid level is the memory register and thresholds are comparators.

#### 3.2 Mathematical Scaffold: Gauge Fields and Phase Space
- **Aharonov-Bohm Effect:** Fundamental reality is not field strength $\mathbf{F}$ but vector potential $\mathbf{A}$ — a pure phase connection. Phase can be extracted where local forces are zero: a robust non-local carrier.
- **Berry's Geometric Phase:** Cyclic evolution accumulates phase $\gamma_n = \oint \mathcal{A}_n(\mathbf{R})\cdot d\mathbf{R}$ where $\mathcal{A}_n = i\langle n|\nabla_{\mathbf{R}} n\rangle$ — the Berry connection, a generalization of the vector potential in the Aharonov-Bohm phase. Depends only on geometry of path, not rate.

**Conclusion:** Phase difference around a closed loop ($\oint d\mathbf{A}$) is the non-local constant governing magnetism, optics, and mechanics.

#### 3.3 Systemic Synthesis: Tensegrity and Kuramoto

In a tensegrity, loading one strut shifts tension throughout the whole system simultaneously — identical to phase relationship propagating in a coupled oscillator network. The Kuramoto model $d\theta_i/dt = \omega_i + K \sum_j \sin(\theta_j - \theta_i)$ treats each unit as a phase-only oscillator. The coupling constant $K$ is the functional analog of prestress level. The structure *is* the computational kernel; compliance is nonlinearity.

- **Four-Phase Clock:** Adiabatic logic requires a four-phase power-clock (evaluate, hold, recover, wait) using AC supply to reduce power and avoid charge accumulation. This is $0^\circ,90^\circ,180^\circ,270^\circ$ breath clock.
- **Empty State:** Not 'None', but a detectable phase void — Kuramoto order parameter $r \approx 0$, or phase singularity — maximum-plasticity register.
- **Readout via Caustics:** Height variations create phase $\Delta\Phi$ which propagates into structured intensity patterns. The pattern *is* the output — geometrically encoded map of internal state.

### 4. The Four Principles as Formal Postconditions

Principles become operative only as predicates over state.

Let Conjunction OS state be:
```
σ = (W, L, D)
  W: multiset[Observation]   -- working registers
  L: dict[Signature, Accumulator] -- latent register
  D: list[Residue]           -- routed during this cycle
```

**P1. Non-Identity:** For every pair (a,b) with surface(a)=surface(b), structural hashes must match: canonical_hash(a.structure)=canonical_hash(b.structure). Violation: surface-identical, structurally distinct observations in W during COMPOSE. Response: raise NonIdentityViolation, abort cycle before EMIT.

**P2. Conservative Residue:** For every filter returning (joint, residue): canonical_content(a)+canonical_content(b)=canonical_content(joint)+canonical_content(residue). Violation: residue None, untyped, or silently compressed. Response: raise UnroutedResidue; cycle does not reach SETTLE.

**P3. Cyclic Closure:** At SETTLE, W empty and L contains only sub-threshold accumulators. Any ready accumulator discharged via crystallization. Violation: W nonempty at SETTLE or ready accumulator remains. Response: phase="open"; next /cycle returns HTTP 423 until closure.

**P4. Non-Additive Composition:** For filter f, f(a,b).joint.structure contains at least one component not pointwise derivable from a or b alone. Violation: filter whose joint is componentwise reducible. Enforced by joint marker edge in merge_graphs.

### 5. The Four-Phase Cycle

One complete cycle is the unit of computation. External clients invoke cycles, not sub-ops.

**SAMPLE:** Probes queried, outputs held in W without combination.
**COMPOSE:** W passed through integrity filter. Survivors = joint outcome; residue routed to L.
**EMIT:** L checked for crystallization condition. Ready accumulators discharge artifact.
**SETTLE:** W zeroed, residue reached destination, artifact handed off. Reports phase="settled".

```python
def cycle(probes, latent_register, prev_phase):
    if prev_phase != "settled":
        raise CycleOpen(prev_phase)

    # SAMPLE
    observations = [probe() for probe in probes]

    # COMPOSE
    joint, residue = integrity_filter(observations)  # may raise P1/P2

    # EMIT
    latent_register.route(residue)                   # P2 enforced
    if latent_register.ready_to_crystallize():
        emission = latent_register.crystallize()
    else:
        emission = None

    # SETTLE
    return {
        "joint": joint,
        "residue": residue,
        "emission": emission,
        "phase": "settled",
    }
```

### 6. The Integrity Filter

Typed I/O:

```python
@dataclass(frozen=True)
class Observation:
    surface: bytes       # presented form
    structure: dict      # typed structural payload
    provenance: str      # which probe produced it

@dataclass(frozen=True)
class Residue:
    signature: bytes     # canonical hash of payload
    payload: dict        # typed remainder
    kind: str            # equivalence-class label

@dataclass(frozen=True)
class Joint:
    surface: bytes
    structure: dict
    provenance: tuple[str, ...]
```

```python
def integrity_filter(a: Observation, b: Observation) -> tuple[Joint, Residue]:
    # P1 Non-Identity
    if a.surface == b.surface and \
       canonical_hash(a.structure) != canonical_hash(b.structure):
        # raises only when structures disagree on a SHARED key, not merely differ
        if has_shared_key_conflict(a.structure, b.structure):
            raise NonIdentityViolation(a, b)

    # P4 Non-Additive Composition
    joint_structure = merge_graphs(a.structure, b.structure)
    joint = Joint(
        surface = a.surface,
        structure = joint_structure,
        provenance = (a.provenance, b.provenance),
    )

    # P2 Conservative Residue
    residue_payload = symmetric_difference(a.structure, b.structure)
    residue = Residue(
        signature = canonical_hash(residue_payload),
        payload = residue_payload,
        kind = classify_kind(residue_payload),
    )
    return joint, residue
```

Operators: `canonical_hash(x) = SHA-256(canonical CBOR RFC 8949)`, deterministic, order-independent. `merge_graphs(s1,s2)` = overlay union + one labelled edge `("joint", prov(s1), prov(s2))` — the non-reducible component. `symmetric_difference` = components in exactly one under canonical form. `classify_kind` = pure function to fixed finite alphabet.

### 7. Residue Routing and Latent Register

Objection: If Non-Identity forbids equating distinct states, how can register accumulate? Answer: identity ≠ equivalence. Distinct canonical forms produce distinct signatures; register accumulates across a *kind* (equivalence class at chosen granularity), never claims two distinct payloads are same payload.

```python
structural_signature(r: Residue) -> bytes := SHA-256(canonical_cbor(r.payload))

class LatentRegister:
    def __init__(self):
        self.accumulators: dict[bytes, Accumulator] = {}

    def route(self, r: Residue | None) -> None:
        if r is None:
            raise UnroutedResidue("filter returned None; P2 violated")
        acc = self.accumulators.setdefault(
            r.signature,
            Accumulator(signature=r.signature, kind=r.kind),
        )
        acc.add(r)

    def ready_to_crystallize(self) -> bool:
        return any(a.exceeds_threshold() for a in self.accumulators.values())

    def crystallize(self) -> Artifact | None:
        ready = [a for a in self.accumulators.values() if a.exceeds_threshold()]
        if not ready: return None
        acc = min(ready, key=lambda a: a.first_seen)  # deterministic
        artifact = acc.emit()
        acc.reset()
        return artifact

@dataclass
class Accumulator:
    signature: bytes
    kind: str
    n: int = 0
    first_seen: float = 0.0
    last_seen: float = 0.0
    entropy: float = 0.0
    exemplars: list[Residue] = field(default_factory=list)

    def exceeds_threshold(self) -> bool:
        # Adaptive: log-scaled count and bounded entropy
        # Coarse kinds fill quickly; fine kinds slowly
        return math.log2(self.n + 1) >= K and self.entropy <= TAU
```

The register is non-monotonic: it discharges when it fires. A register that never emits is reporting no stable kind.

### 8. Crystallization

Context-free emission invariant:
```
for all distinct register contexts C1, C2:
    decode(artifact, C1) = decode(artifact, C2)
```

```python
@dataclass(frozen=True)
class Artifact:
    signature: bytes
    content: dict
    provenance: tuple[str, ...]
    timestamp: float

def crystallize(acc: Accumulator) -> Artifact | None:
    if not acc.exceeds_threshold(): return None
    artifact = Artifact(
        signature = acc.signature,
        content = acc.snapshot(),
        provenance = tuple(e.signature.hex()[:8] for e in acc.exemplars),
        timestamp = now(),
    )
    acc.reset()
    return artifact
```

Artifact is same kind as probe Observation. System can feed its own emissions to other instances across network without translation layer.

### 9. Worked Cycle (Trace)

Setup: p_lex (lexical), p_sem (semantic), K=log2(4)=2, TAU=0.8

**Cycle 1 — route**
a = Observation(surface=b"the dog runs", structure={"tokens":[...], "pos":[...]}, provenance="p_lex")
b = Observation(surface=b"the dog runs", structure={"tokens":[...], "sem":{...}}, provenance="p_sem")
- integrity_filter: surfaces equal, shared key tokens agrees, disjoint elsewhere. NOT violation. joint = tokens+pos+sem+_joint_edge. residue = {pos, sem}, kind="lex_sem_divergence", signature=8c4a...e2f1
- route: new accumulator n=1 entropy=0.4, log2(2)=1 <2 no emission, phase=settled

**Cycle 2 — route same kind**
Different sentence same shape. Residue normalizes to same signature 8c4a...e2f1, n=2 entropy=0.5 log2(3)=1.58 <2 no emission.

**Cycle 3 — crystallize**
n=3 entropy=0.6 log2(4)=2 >=K and <=TAU => THRESHOLD MET
artifact = Artifact(signature=8c4a...e2f1, content=snapshot, provenance=(...), timestamp=...)
acc.reset() — state at rest after cycle 3 == state before cycle 1 except artifact produced.

**Cycle 4 — injected violation:** surface equal, shared key conflict -> raise NonIdentityViolation -> 409.

Lesson: surface equivalence + disjoint contribution = clean joint; shared-key conflict = catastrophic failure.

### 10. Three Rails: Hanoi, Toffoli, and Justification of Setup Cost

**Hanoi:** With 2 pegs, problem impossible. With 3 pegs, state graph strongly connected, every move invertible, no sink. Third peg is ancilla — holds displaced disk while another moves. That is why reversibility needs 3.

**Toffoli:** Same topology: 2 controls, 1 ancilla, 3 rails out. Minimum-arity gate that makes classical universal computation possible under reversibility constraint. Two-input reversible gates cannot realize AND without losing information. Three is minimum where gate can be both universal and its own inverse.

In Conjunction OS, commit decision is three-rail:
- Control 1: density (accumulator readiness)
- Control 2: convergence (routing complete)
- Ancilla: potential artifact token

Gate flips ancilla (commits artifact) iff both controls high. Because operation is its own inverse, ancilla history is replayable log of emissions: system reversible from any cycle boundary, like Hanoi.

What does it buy? Franklin's balloon question: upfront cost real — 2^n-1 moves vs impossible, ancilla prep per gate, per-cycle closure latency. Landauer fixes credit: every irreversible bit erasure dissipates >= k_B T ln2 heat. Reversible computation pays gate-count and bookkeeping front-loaded instead. Conjunction OS buys auditable emission history, crash-recoverable state (replay ledger to last SETTLE), debuggable cycles (no silent loss), structurally safe migration (sign document under pinned hash, migrate forward).

Two-rail analogue (density + artifact alone without convergence) would lose information at commit. Four-rail would be redundant. Three is what structure requires.

A wire transmits. A gate makes a field. Each Toffoli operation opens and closes a three-rail field that commits structure through it rather than carrying signal across it.

### 11. System Surface and HTTP Semantics — Physical Mapping

External surface mirrors cycle: one request, one cycle.

**Physical architecture proposed in Phase Arithmetic:**
1. Outermost Shell (Global Memory): Room Acoustics — standing waves as persistent room modes, boundary conditions
2. Middle Layer (Temporal Coordination): 4-Channel Phase Controller (0°,90°,180°,270° pneumatic/magneto-fluidic relaxation oscillators) — Breath Clock
3. Inner Core (Actuation): Tensegrity Micro-Motor — coreless motor in compliant structure, rotation read by disturbance coupling, variable impedance relative to acoustic field

**Software mapping (Conjunction OS):**
1. Outer Shell = Append-only event ledger + canonical latent document (global memory field)
2. Middle = SAMPLE/COMPOSE/EMIT/SETTLE cycle + 4-phase clock enforcement
3. Inner Core = integrity_filter + LatentRegister where prestress K = coupling constant, prestress redistribution = symmetric_difference routing, caustics readout = Artifact emission

```
POST /cycle
  Headers: Idempotency-Key: <uuid> (required)
  Behavior:
    - if Idempotency-Key matches prior: return stored response without re-running
    - if prev_phase != "settled": return 423 cycle_open
    - if NonIdentityViolation: return 409 typed body
    - else: return 200 {joint, residue, emission, phase}

GET /state
  Returns: phase, latent snapshot, ETag = sha256(canonical_state)
  Clients may use If-Match for CAS

GET /artifacts
  Returns self-contained emissions; idempotent; safe to retry

GET /stream
  SSE; one event per phase transition; monotonically increasing phase_sequence for de-dup

Persistence: single canonical document holding L. Every cycle = read, in-memory compute, atomic write (rename-into-place). Ledger records phase transitions. On crash, replay ledger to last SETTLE. Server holds no hidden accumulation.
```

### 12. Evaluation — Four Falsifiable Metrics

**Residue Conservation Ratio (RCR):**
RCR = bytes(canonical(routed_residue) ∪ canonical(joint_structure)) / bytes(canonical(inputs))
Target 1.0. <1.0 = silent loss, P2 violation.

**Non-Identity Violation Detection Rate (NIVDR):**
Against test stream with known injected surface-identical, structure-conflicting pairs:
NIVDR = detected / injected
Target 1.0. Falling = canonical_hash conflating.

**Cycle Closure Latency (CCL):**
CCL = t(SETTLE) - t(SAMPLE), report p50,p95,p99. Target stability, not minimization. p99 drifting up = register accumulating without discharging.

**Emission Fidelity (EF):**
For each artifact, instantiate second empty Conjunction OS, feed artifact, check equivalent decode.
EF = successful_decodes / total_emissions
Target 1.0. <1.0 = emission depended on producing register, violation of context-free invariant.

Synthetic probe stream with controlled surface-collision rates and tunable kind-granularity exercises all four. Monotonic-accumulator baseline (no crystallization) provides contrast.

### 13. Discussion

**Gradient descent:** Loss scalar equates structurally distinct errors. y=[1,0,0], yhat=[0.4,0.5,0.1] cross-entropy ~0.92 absorbs three disagreements. Conjunction routes typed residue:
```
residue.payload = {
  "under_confident": {"index":0, "delta":0.6},
  "over_confident": {"index":1, "delta":0.5},
  "near_correct": {"index":2, "delta":0.1},
}
kind="prediction_mismatch"
```
Each kind accumulates separately. Only kinds crossing adaptive threshold produce discrete revision. Learning = phasic commitment, not continuous descent.

**Memory:** Conventional context window monotonic until pruned, lossy. Latent register non-monotonic — discharges via crystallization. Size bounded by emission rate, not cap.

**Agents:** Cycle = natural unit of action. Agent takes one cycle at a time; each either produces artifact (commitment to external) or not. No unbounded chain; accumulated but not emitted = not yet acted.

### 14. Related Work and Limitations

Reversible computing (Toffoli 1980, Bennett 1973, Fredkin-Toffoli 1982) provides gate discipline. Landauer 1961 underwrites Conservative Residue. seL4, Unison (content-addressed), Flow-based programming (Morrison 1994) anticipate routing over mutation.

**Limitations owned:**
- Phasic execution pays per-cycle overhead; not drop-in where raw throughput dominates
- Signature collision bounded by hash; document should pin hash name for migration via re-signing
- Distributed crystallization across shards open — consensus shape via Artifact protocol not worked out
- Three-rail reversibility argument topological/computational; hardware instantiation (FPGA/reversible-logic measuring thermodynamic overhead vs Landauer) is future work
- Non-additive marker edge convention, not theorem; needs algebraic spec

### 15. Conclusion

Conjunction OS is organized around what it will not do. It will not collapse distinct states. It will not erase residue. It will not allow cycles to run open. It will not treat composition as addition. Each refusal removes a class of silent failure load-bearing in conventional systems.

Cost: cyclic not streaming, phasic not monotonic, discrete artifacts not continuous traces. Benefit: every piece of information either finds a destination or surfaces as a violation — nothing falls quietly out of the record.

The principles are now postconditions. Operators are typed. Cycle walked on concrete data. HTTP surface has idempotency key, ETag, crash-recovery contract. Four metrics make architecture falsifiable. What remains is implementation and measurement: reference instance run, evaluated against four targets, criticized where behavior diverges.

Single-cycle eval will not flatter this architecture. Three-rail reversibility is setup cost, not per-step advantage, and payoff appears only over many cycles — in emissions that survive migration, cycles replayable from ledger boundary, debugging traces with no silent steps to lose.

---

### Summary Table: From Gap to Mechanism

| Conceptual Requirement | Foundational Problem (Cavity) | Unifying Principle (Phase) | Software Implementation (Conjunction OS) | Physical Implementation |
| :--- | :--- | :--- | :--- | :--- |
| State Variable | Non-discrete, must include Empty | Phase Offset Δφ, Potentials A | Observation{surface, structure, provenance} + Residue signature | Fluid level / prestress tension / voltage phase angle |
| Computation Rule | Operative Admissibility | Interference: Output ∝ Σ A_i e^{iφ_i} | integrity_filter with canonical_hash + joint marker edge | Caustics formation, beating frequencies |
| Memory/Storage | Reversibility, lasting retention | Topological Invariant: Geometric Phase γ_n | LatentRegister L + append-only ledger + canonical doc | Flux trapping, prestress lock K, room modes |
| Core Operation | Remainder must be signal | Harmonic interaction | Toffoli 3-rail commit: density+convergence controls, artifact ancilla | Differential gearing, residual tension |

---

*This unified document merges The Unbuilt Gate cavity report (Sections I-III) and Conjunction OS v3 whitepaper (Sections 4-14). The logical Toffoli function is retained only as the minimal three-rail topology justifying reversibility cost.*
