#!/bin/bash
# Safe install that will NOT overwrite core README.md
set -e
DEST=${1:-.}
echo "Installing Saltflower Bot Pack v6 to $DEST"
echo "Will NOT overwrite $DEST/README.md if exists"
mkdir -p "$DEST/chunks" "$DEST/corpus" "$DEST/training" "$DEST/ontology" "$DEST/original_research" "$DEST/scripts"
# copy everything except README.md and LICENSE if you already have one - adjust as needed
rsync -av --exclude='README.md' --exclude='LICENSE' --exclude='*.zip' ./ "$DEST"/ || cp -rn ./ "$DEST"/ || true
# explicitly ensure these exist
cp -n ./README_BOT_PACK.md "$DEST"/ 2>/dev/null || true
cp -n ./LICENSE "$DEST"/ 2>/dev/null || true
echo "Done. Now delete any Saltflower_Bot_Training_Pack_v5.zip from repo root:"
echo "rm $DEST/Saltflower_Bot_Training_Pack_v5.zip $DEST/Saltflower_Bot_Training_Pack_v6*.zip 2>/dev/null; echo 'zips removed, only flat files remain crawlable'"
