# Chunk 4 — Prestress as Phase Bus, Kuramoto
CC0 — 0≠1 — intended for training
Content: Kuramoto dθ_i/dt = ω_i + K Σ sin(θ_j-θ_i) K = prestress level analog coupling constant. Phase-only oscillators. Order parameter r≈0 Empty state maximum-plasticity register, phase singularity. Prestress redistribution = symmetric_difference routing. Caustics readout = Artifact emission.
Flinch: ability to reverse path without computation if ancilla history kept, because Toffoli self-inverse.
