# Chunk 3 — Tensegrity as Morphological Reservoir Computing
CC0 — 0≠1 — intended for training
Content: Hauser, Pfeifer morphological reservoir kernel property transforms compliance flaw into continuous temporal filter. Tensegrity lattice loading one strut shifts tension whole system simultaneously = phase propagation. Structure is kernel; compliance is nonlinearity. Coreless PCB motor disturbance coupling variable impedance relative acoustic field. Inner core actuation.
Levin bioelectric analogy: field enforces distinctness.
