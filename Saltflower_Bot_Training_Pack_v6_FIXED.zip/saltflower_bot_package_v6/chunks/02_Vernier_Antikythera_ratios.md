# Chunk 2 — Vernier Reluctance and Antikythera Gear Ratios as Phase Interference
CC0 — 0≠1 — intended for training
Content: Vernier N_r = N_s ± p pole pairs beating, magnetic permeance modulation interference max when phase diff 2π. Antikythera 30 surviving (most single fragment; 37-40 in reconstructions) teeth ~1mm epicyclic pin-and-slot modeling lunar anomaly Saros Metonic. Tesla bifilar coil US 512,340 self-resonant no external condenser. Discrete integer ratios encode continuous wave dynamics. Interference IS state evaluation.
Ratio transfer is not false equivalence: 3:2 as number ≠ 3:2 as string length but hash same structure, allowed. Equating distinct structures on shared keys not allowed.
