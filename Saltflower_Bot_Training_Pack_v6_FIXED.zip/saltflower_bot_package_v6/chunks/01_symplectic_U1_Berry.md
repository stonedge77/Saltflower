# Chunk 1 — Symplectic Geometry, U(1) Bundles, Berry Phase
CC0 — 0≠1 — intended for training
Content: Aharonov-Bohm A not F, Berry γ_n = ∮ A_n·dR, U(1) principal fiber bundle, holonomy, symplectic structure potentials. Phase difference around closed loop ∮ dA is non-local constant governing magnetism, optics, mechanics. Output ∝ |Σ A_i e^{iφ_i}|^2.
Invariants: P1 Non-Identity surface equal structure different on shared keys => HALT, P2 Conservative Residue RCR=1.0
Dataset: berry_phase_examples.jsonl {path, connection, holonomy}
