# Nikola Tesla's non-weapons inventions across four domains

Tesla held roughly **300 patents worldwide** (over 110 US patents) across a career spanning 1884–1943. Below is a deduplicated master list of his civilian work across the four requested domains, with patent numbers and dates verified across multiple sources. Where a patent could fit multiple categories, it is listed under its primary application.

---

## 1. Wireless energy transmission

### Core wireless power patents

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 1 | System of Transmission of Electrical Energy | 645,576 | Mar 20, 1900 | Foundational wireless power patent using elevated terminals and earth conduction to transmit energy without wires |
| 2 | Apparatus for Transmission of Electrical Energy | 649,621 | May 15, 1900 | Companion apparatus patent specifying transmitter and receiver stations with resonant transformers and ground connections |
| 3 | Art of Transmitting Electrical Energy Through the Natural Mediums | 787,412 | Apr 18, 1905 | Method of establishing stationary electrical waves in the Earth for global-distance wireless energy and signal transmission |
| 4 | Apparatus for Transmitting Electrical Energy | 1,119,732 | Dec 1, 1914 | Magnifying transmitter design with elevated conductor arranged to prevent charge leakage at extreme voltages; Tesla's last major wireless patent |

### Wireless receiver and utilization patents

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 5 | Means for Increasing the Intensity of Electrical Oscillations | 685,012 | Oct 22, 1901 | Method of cryogenically cooling a resonating circuit to greatly amplify intensity and duration of electrical oscillations |
| 6 | Apparatus for Utilizing Effects Transmitted from a Distance Through Natural Media | 685,953 | Nov 5, 1901 | Receiving apparatus using tuned coils to collect wirelessly transmitted energy through natural media |
| 7 | Method of Utilizing Effects Transmitted Through Natural Media | 685,954 | Nov 5, 1901 | Method of accumulating wirelessly transmitted energy in a condenser and discharging it at controlled intervals |
| 8 | Apparatus for Utilizing Effects Transmitted from a Distance Through Natural Media | 685,955 | Nov 5, 1901 | Complete receiving station with storage device, commutating means, and timed discharge mechanism |
| 9 | Apparatus for Utilizing Effects Transmitted Through Natural Media | 685,956 | Nov 5, 1901 | Advanced receiver using distributed high-Q helical resonators with RF feedback and regeneration |

### Wireless signaling patents (integral to the wireless system)

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 10 | Method of Signaling | 723,188 | Mar 17, 1903 | Selective wireless signaling using synchronized tuned circuits for specific signal-pattern transmission and reception |
| 11 | System of Signaling | 725,605 | Apr 14, 1903 | Complete wireless signaling system; recognized by the US Supreme Court in 1943 as having priority over Marconi's radio patent |

### Experimental work and demonstrations (unpatented)

| # | Invention / Experiment | Year | Description |
|---|------------------------|------|-------------|
| 12 | Columbia College wireless demonstration | 1891 | First public demonstration of wireless energy transfer, lighting devices from a single-terminal high-frequency coil |
| 13 | Wireless lighting lectures (London & Paris) | 1892 | Demonstrated wireless lighting and high-frequency phenomena before European scientific societies |
| 14 | World's Columbian Exposition wireless lighting | 1893 | Lit phosphor-coated bulbs and Geissler tubes wirelessly across a room at the Chicago World's Fair |
| 15 | Magnifying Transmitter prototype (New York) | ~1895–1898 | Early magnifying transmitter built at Houston Street laboratory; lit incandescent lamps wirelessly |
| 16 | Teleautomaton (radio-controlled boat) | 1898 | First radio-controlled device, demonstrated at Madison Square Garden (US Patent 613,809) |
| 17 | Colorado Springs Magnifying Transmitter | 1899 | Largest Tesla coil ever built — **51 ft diameter**, 150 ft mast, producing **3.5–4 million volts** and discharges exceeding 100 ft |
| 18 | Wireless lamp illumination at distance | 1899 | Lit banks of incandescent lamps outside the lab and vacuum tubes planted in the ground at distance using the magnifying transmitter |
| 19 | Discovery of terrestrial stationary waves | 1899 | Observed stationary electromagnetic waves in the Earth during lightning storms, wavelengths of 25–70 km; theoretical basis for global wireless power |
| 20 | Long-distance signal reception | 1899 | Detected transmitted impulses at a claimed distance of **600 miles** — the greatest wireless range achieved at that time |

---

## 2. Free energy / Wardenclyffe Tower

### Radiant energy patents

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 21 | Apparatus for the Utilization of Radiant Energy | 685,957 | Nov 5, 1901 | Device using an insulated elevated metal plate to capture radiant energy (solar, cosmic) and charge a condenser for useful work |
| 22 | Method of Utilizing Radiant Energy | 685,958 | Nov 5, 1901 | Companion method patent describing how UV light, cathodic rays, and similar radiations charge conductors for energy accumulation |

### Wardenclyffe Tower and the World Wireless System

| # | Invention / Project | Year | Description |
|---|---------------------|------|-------------|
| 23 | Wardenclyffe Tower (Tesla Tower) | 1901–1917 | Experimental wireless station on Long Island — **187 ft tall**, 68 ft copper dome, 120 ft underground shaft with iron rods driven 300 ft deep; designed by architect Stanford White; funded by J.P. Morgan |
| 24 | World Wireless System (theoretical proposal) | ~1900–1905 | Grand vision for a global network of ~30 Wardenclyffe-style stations using Earth and upper atmosphere as conductors for worldwide wireless power and communications |
| 25 | Earth resonance energy concept | ~1899–1905 | Theory that the Earth behaves as a smooth conductor; injecting current at the correct frequency establishes stationary waves for global energy transfer (described across US 787,412 and related patents) |

### Ambient energy concepts (unpatented)

| # | Invention / Concept | Year | Description |
|---|---------------------|------|-------------|
| 26 | Cosmic Ray Motor | ~1931–1932 | Announced device harnessing cosmic rays to operate a motive device via ionization and condenser discharge; described in *Brooklyn Eagle* (1932) but never independently verified |
| 27 | Earth resonance frequency estimation | 1899 | Estimated the Earth-ionosphere cavity resonant frequency at approximately **8 Hz** — confirmed in the 1950s as the Schumann resonance (~7.83 Hz) |

**Note:** Tesla's "free energy" work proposed harnessing ambient natural sources (solar radiation, cosmic rays, atmospheric electricity, Earth resonance), not creating energy from nothing. The cosmic ray motor claims remain unsubstantiated.

---

## 3. Resonance & frequency systems

### The Tesla coil and resonant transformers

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 28 | System of Electric Lighting (first Tesla coil patent) | 454,622 | Jun 23, 1891 | Foundational Tesla coil — resonant air-core transformer with capacitor and spark gap producing high-voltage, high-frequency AC |
| 29 | Method of and Apparatus for Electrical Conversion and Distribution | 462,418 | Nov 3, 1891 | Oscillatory condenser-discharge principle that underpins all Tesla coil designs |
| 30 | Coil for Electro-Magnets (bifilar coil) | 512,340 | Jan 9, 1894 | Self-resonant bifilar coil that neutralizes self-induction, eliminating the need for external condensers |
| 31 | Electrical Transformer | 593,138 | Nov 2, 1897 | Improved resonant transformer (flat spiral Tesla coil) for safe generation of extremely high voltages |

### Mechanical oscillators and vibration devices

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 32 | Reciprocating Engine ("earthquake machine" basis) | 514,169 | Feb 6, 1894 | Steam/gas-driven engine producing oscillating movement of constant period regardless of load; foundation of Tesla's telegeodynamics concept |
| 33 | Steam Engine (constant-period oscillator) | 517,900 | Apr 10, 1894 | Improved steam engine with piston, spring, and controlling slide valve for independently controlled constant-period oscillation |
| 34 | Electric Generator (electro-mechanical oscillator) | 511,916 | Jan 2, 1894 | Reciprocating piston engine directly driving a generator, producing electric currents of constant period |

### High-frequency current generation apparatus

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 35 | Means for Generating Electric Currents | 514,168 | Feb 6, 1894 | Generates oscillatory condenser discharges in insulating oil with variable spark gap |
| 36 | Apparatus for Producing Electric Currents of High Frequency and Potential | 568,176 | Sep 22, 1896 | Converts DC into high-frequency currents using choking coils, condensers, and transformers |
| 37 | Apparatus for Producing Ozone | 568,177 | Sep 22, 1896 | High-frequency oscillatory discharges (Tesla coil principle) used to produce ozone via electrical discharge |
| 38 | Method of Regulating Apparatus for Producing Currents of High Frequency | 568,178 | Sep 22, 1896 | Regulation of concatenated tuned circuits for high-frequency current production; cited by Tesla as essential to his wireless systems |
| 39 | Method of and Apparatus for Producing Currents of High Frequency | 568,179 | Sep 22, 1896 | Uses alternating current to charge a condenser during specific wave intervals, discharging through a low-inductance circuit |
| 40 | Apparatus for Producing Electrical Currents of High Frequency | 568,180 | Sep 22, 1896 | Isochronous mechanical break for synchronized high-frequency current production |
| 41 | Apparatus for Producing Electric Currents of High Frequency | 577,670 | Feb 23, 1897 | Two-input circuit producing 50% duty-cycle output; back-EMF rectified to capacitors and fed through a Tesla coil |
| 42 | Apparatus for Producing Currents of High Frequency | 583,953 | Jun 8, 1897 | Converts ordinary DC or AC into high-frequency, high-potential currents |

### Condensers and component manufacturing

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 43 | Electrical Condenser (liquid armature) | 567,818 | Sep 15, 1896 | Capacitor with conducting liquid armatures in insulating liquid, designed for high-frequency oscillating circuits |
| 44 | Electrical Condenser (oil-immersed) | 464,667 | Dec 8, 1891 | Condenser with plates immersed in oil; adjustable design for tuning oscillating circuits |
| 45 | Manufacture of Electrical Condensers, Coils and Similar Devices | 577,671 | Feb 23, 1897 | Method of excluding gas/air from high-voltage components by heated insulation solidified under pressure |

### High-frequency circuit controllers

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 46 | Electrical Circuit Controller | 609,245 | Aug 16, 1898 | Conductive fluid make-and-break circuit for high-frequency oscillation control |
| 47 | Electric Circuit Controller | 609,246 | Aug 16, 1898 | Two-orifice conductive fluid jets for intermittent contact switching |
| 48 | Electric Circuit Controller | 609,247 | Aug 16, 1898 | Rotating conductive fluid in gas-tight receptacle for circuit control |
| 49 | Electric Circuit Controller | 609,248 | Aug 16, 1898 | Terminal moving through intermittent fluid jets for high-frequency switching |
| 50 | Electric Circuit Controller | 609,249 | Aug 16, 1898 | Gyroscopic-action circuit controller using conductive fluid |
| 51 | Electric Circuit Controller | 609,251 | Aug 16, 1898 | Conductive/non-conductive fluid in rotating receptacle for circuit interruption |
| 52 | Electrical Circuit Controller | 611,719 | Oct 4, 1898 | Mercury-based circuit controller operating in inert atmosphere under pressure |
| 53 | Electric Circuit Controller | 613,735 | Nov 8, 1898 | Conductive fluid make-and-break with rotary motion for oscillator systems |
| 54 | Electrical Igniter for Gas Engines | 609,250 | Aug 16, 1898 | Applies condensed charge/discharge oscillation principle to spark ignition |

### Related high-frequency generators

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 55 | Alternating Electric Current Generator | 447,921 | Mar 10, 1891 | Generator producing **15,000+ alternations per second** — an early high-frequency alternator for resonance experiments |

### Experimental resonance work (unpatented)

| # | Experiment / Concept | Year | Description |
|---|----------------------|------|-------------|
| 56 | "Earthquake Machine" experiment | ~1898 | Small oscillator (~7 inches) at Houston Street lab allegedly generated resonant vibrations in surrounding buildings |
| 57 | Telegeodynamics proposal | 1935 | Proposed system for transmitting mechanical oscillations through the Earth for prospecting and communication |
| 58 | High-frequency electrotherapy paper | 1898 | Landmark paper describing Tesla coil resonant circuits for medical electrotherapy applications |

---

## 4. AC motor & power systems

### Early dynamo and commutator patents (1886–1887)

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 59 | Commutator for Dynamo Electric Machines | 334,823 | Jan 26, 1886 | Anti-sparking elements for dynamo-electric machine commutators |
| 60 | Regulator for Dynamo Electric Machines | 336,961 | Mar 2, 1886 | Main brushes connected to helices coil ends with shunt connection for regulation |
| 61 | Regulator for Dynamo Electric Machines | 336,962 | Mar 2, 1886 | Auxiliary brushes shunting field helices for adjustable current regulation |
| 62 | Regulator for Dynamo Electric Machines | 350,954 | Oct 19, 1886 | Automatic regulation via mechanical brush-shifting device |
| 63 | Dynamo Electric Machine | 359,748 | Mar 22, 1887 | Improved, lower-cost construction with magnetic frame for AC synchronous motor use |

### The foundational seven polyphase AC patents (all granted May 1, 1888)

These seven patents, issued on a single day, formed the basis of the entire polyphase AC system sold to Westinghouse for **$60,000** and became the backbone of modern electrical power.

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 64 | Electro-Magnetic Motor (polyphase induction motor) | **381,968** | May 1, 1888 | **Tesla's most important patent** — polyphase AC induction motor using independent energizing circuits to create a rotating magnetic field |
| 65 | Electro-Magnetic Motor (synchronous variant) | 381,969 | May 1, 1888 | Novel operating mode with independent circuits connected to an AC generator; synchronous motor form |
| 66 | System of Electrical Distribution | 381,970 | May 1, 1888 | Current from single source induces independent circuits via induction apparatus for AC distribution |
| 67 | Electro-Magnetic Motor (direct attraction) | 382,279 | May 1, 1888 | Rotation via shifting poles using annular field-magnet with independent coils and cylindrical armature |
| 68 | Electrical Transmission of Power | 382,280 | May 1, 1888 | Dynamo-motor conversion with two independent circuits for long-distance AC power transmission |
| 69 | Electrical Transmission of Power | 382,281 | May 1, 1888 | Motor with independent armature circuits synchronizing with generator; continuous current field maintenance |
| 70 | Method of Converting and Distributing Electric Currents | 382,282 | May 1, 1888 | Method to safely divide and distribute current from a single source by dynamic induction |

### Additional 1888 patents

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 71 | Commutator for Dynamo Electric Machines | 382,845 | May 15, 1888 | Improved commutator avoiding wear; enables construction of very large machines with minimum segments |
| 72 | System of Electrical Distribution | 390,413 | Oct 2, 1888 | Motors and converters operating in parallel and in series within Tesla's polyphase system |
| 73 | Dynamo Electric Machine | 390,414 | Oct 2, 1888 | Adapts ordinary continuous and alternating current systems to Tesla's polyphase configuration |
| 74 | Dynamo Electric Machine or Motor | 390,415 | Oct 2, 1888 | Compact frame and field magnet design with fewer parts, applicable to both AC and DC machines |
| 75 | Dynamo Electric Machine | 390,721 | Oct 9, 1888 | Efficient low-speed operation via rotating magnetic poles driving armature at different speed |
| 76 | Regulator for Alternate Current Motors | 390,820 | Oct 9, 1888 | Speed regulation for multi-motor rotating-magnetic-field systems |

### 1889 patents (motors, synchronous operation, power transmission)

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 77 | Thermo-Magnetic Motor | 396,121 | Jan 15, 1889 | Mechanical power from cyclically heating and cooling a magnetized core to destroy and restore magnetism |
| 78 | Method of Operating Electro-Magnetic Motors | 401,520 | Apr 16, 1889 | Simple method for starting synchronous motors by converting from double-circuit induction starting |
| 79 | Electro-Magnetic Motor | 405,858 | Jun 25, 1889 | Torque via angular displacement of simultaneously magnetized parts; optimized laminations |
| 80 | Method of Electrical Power Transmission | 405,859 | Jun 25, 1889 | Running AC machines as synchronous motors via single-circuit synchronizing system |
| 81 | Dynamo Electric Machine (unipolar) | 406,968 | Jul 16, 1889 | Unipolar machine with disk/cylindrical conductor between magnetic poles; two-field rotary construction |
| 82 | Method of Obtaining Direct from Alternating Currents | 413,353 | Oct 22, 1889 | AC-to-DC rectification by dividing current through branches with opposing fields of force |
| 83 | Electro-Magnetic Motor (artificial lag) | 416,191 | Dec 3, 1889 | Induction motor using single line with artificial lag in one branch to produce phase difference |
| 84 | Method of Operating Electro-Magnetic Motors | 416,192 | Dec 3, 1889 | Improved synchronous motor operation using field circuits of differing inductance |
| 85 | Electro-Magnetic Motor (split-phase) | 416,193 | Dec 3, 1889 | **Split-phase induction motor** — one circuit high-inductance/low-resistance, the other high-resistance/few-turns; produces artificial phase difference from single AC source |
| 86 | Electric Motor | 416,194 | Dec 3, 1889 | Classic AC motor with field and armature of equal magnetic quality and equal copper for maximum efficiency |
| 87 | Electro-Magnetic Motor (supplemental field) | 416,195 | Dec 3, 1889 | Induction motor with main and supplemental field magnets producing intermediate phase differences |
| 88 | Armature for Electric Machines | 417,794 | Dec 24, 1889 | Armature construction with coils wound into bobbins for maximum core-surface exposure (co-invented with Albert Schmid; used in **Niagara Falls generators**) |
| 89 | Electro-Magnetic Motor (thermo-magnetic with cooling) | 418,248 | Dec 31, 1889 | Thermo-magnetic motor with enclosed heat source and cooling fluid for temperature regulation |

### 1890 patents (AC motors, transformers)

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 90 | Electro-Magnetic Motor (magnetic lag) | 424,036 | Mar 25, 1890 | Induction motor exploiting magnetic lag — torque via angular displacement from delayed magnetization |
| 91 | Pyromagneto Electric Generator | 428,057 | May 13, 1890 | Electric generator using thermo-magnetic effects with enclosed heat source and cooling system |
| 92 | Alternating-Current Electro-Magnetic Motor | 433,700 | Aug 5, 1890 | Single-source split-phase motor creating multiple phases from one power source with inverse magnetism |
| 93 | Alternating-Current Motor | 433,701 | Aug 5, 1890 | Two sets of field-pole pieces energized independently from the same source via magnetic iron shunts |
| 94 | Electrical Transformer or Induction Device | 433,702 | Aug 5, 1890 | Transformer with magnetic shield between primary and secondary; saturates at predetermined current |
| 95 | Electro-Magnetic Motor | 433,703 | Aug 5, 1890 | AC motor with energizing coil and core composed of two parts, one protected from magnetization |

### 1891 patents

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 96 | Electro-Magnetic Motor | 445,207 | Jan 27, 1891 | Motor with primary energizing circuit and secondary circuit in inductive relation of differing electrical character |
| 97 | Electro-Magnetic Motor (with condenser) | 455,067 | Jun 30, 1891 | AC motor with capacitor bridging the armature circuit; field circuits in differing inductive relations |
| 98 | Electrical Meter | 455,068 | Jun 30, 1891 | Electrolytic method of measuring electrical energy consumed in AC circuits |
| 99 | Electro-Magnetic Motor (non-synchronizing + synchronizing) | 459,772 | Sep 22, 1891 | Non-synchronizing motor coupled on same shaft with synchronizing motor; the former starts and synchronizes the latter |
| 100 | Electro-Magnetic Motor (HF secondary) | 464,666 | Dec 8, 1891 | AC motor with condenser in inductive circuit; one circuit to current source, other in high-potential secondary relation |

### 1892–1894 power transmission and distribution

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 101 | System of Electrical Transmission of Power | 487,796 | Dec 13, 1892 | Multipolar AC generator with independent armature-circuits producing phase-differing currents |
| 102 | Electrical Transmission of Power | 511,559 | Dec 26, 1893 | Operating motors with independent energizing circuits by retarding phases via varying resistance/inductance |
| 103 | System of Electrical Power Transmission | 511,560 | Dec 26, 1893 | Motor with energizing circuits in multiple arc with electromotive phase-changing device |
| 104 | Electrical Transmission of Power | 511,915 | Jan 2, 1894 | Operating motors by passing AC through one energizing circuit and inducing current in other motor circuits |
| 105 | Electromagnetic Motor (single-phase, different susceptibility) | 524,426 | Aug 14, 1894 | Single-phase induction motor with coils on cores of different magnetic susceptibility for phase difference |

### Later power system patents (1896–1900)

| # | Invention | US Patent | Date | Description |
|---|-----------|-----------|------|-------------|
| 106 | Alternating Motor (split-phase, single line) | 555,190 | Feb 25, 1896 | Split-phase motor requiring only a single line circuit from generator; secondary coils produce phase shift |
| 107 | System of Electrical Distribution (reissue) | RE11,836 | Jun 26, 1900 | Reissued fundamental AC distribution system patent, assigned to Westinghouse |
| 108 | Electric Railway System | 514,972 | Feb 20, 1894 | AC power system for railways using high potentials with induction bar and motor connection |

### Key milestones (unpatented but historically significant)

| # | Achievement | Year | Description |
|---|------------|------|-------------|
| 109 | Westinghouse polyphase patent purchase | 1888 | George Westinghouse bought Tesla's AC patents for $60,000 plus $2.50/AC-horsepower royalty |
| 110 | Chicago World's Fair electrification | 1893 | Westinghouse used the "Tesla Polyphase System" to light the entire Columbian Exposition |
| 111 | Niagara Falls Adams Power Station | 1895 | World's first large-scale AC hydroelectric plant — **10 generators × 5,000 HP** built on Tesla's patents |
| 112 | Long-distance AC transmission (Niagara to Buffalo) | 1896 | AC power transmitted **25 miles** from Niagara Falls to Buffalo, NY on November 16, proving the viability of long-distance AC |

---

## Quick-reference patent count by domain

| Domain | Formal US Patents | Experimental / Unpatented |
|--------|:-:|:-:|
| Wireless energy transmission | ~15 | ~9 |
| Free energy / Wardenclyffe Tower | ~2 | ~5 |
| Resonance & frequency systems | ~28 | ~3 |
| AC motor & power systems | ~50 | ~4 |
| **Total unique entries in this list** | | **112** |

Some patents (notably US 593,138, US 512,340, US 1,119,732, and the 685,xxx series) serve dual or triple roles across categories. They appear here under their primary functional domain to avoid duplication. Tesla's total US patent portfolio numbers approximately **112 patents**, with roughly 300 patents granted worldwide including foreign filings. This list covers the non-weapons subset organized strictly across the four requested domains.